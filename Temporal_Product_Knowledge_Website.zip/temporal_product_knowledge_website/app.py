from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

app = Flask(__name__)
CORS(app)
DB_PATH = Path(__file__).with_name("temporal_product_knowledge.db")


def now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def connect_db():
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    with connect_db() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL, category TEXT DEFAULT '',
            description TEXT DEFAULT '', created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS knowledge_entries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id INTEGER NOT NULL, topic TEXT NOT NULL, content TEXT NOT NULL,
            version INTEGER NOT NULL DEFAULT 1, valid_from TEXT NOT NULL, valid_to TEXT,
            source TEXT DEFAULT '', confidence REAL DEFAULT 1.0,
            FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS algorithms (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL, purpose TEXT DEFAULT '', steps TEXT DEFAULT '',
            status TEXT DEFAULT 'incomplete', created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS weaknesses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            algorithm_id INTEGER NOT NULL, description TEXT NOT NULL,
            severity TEXT DEFAULT 'medium', mitigation TEXT DEFAULT '', created_at TEXT NOT NULL,
            FOREIGN KEY(algorithm_id) REFERENCES algorithms(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS evolution_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            entity_type TEXT NOT NULL, entity_id INTEGER NOT NULL,
            change_type TEXT NOT NULL, summary TEXT NOT NULL, changed_at TEXT NOT NULL
        );
        """)


def log_change(conn, entity_type, entity_id, change_type, summary):
    conn.execute(
        """INSERT INTO evolution_log
        (entity_type, entity_id, change_type, summary, changed_at)
        VALUES (?, ?, ?, ?, ?)""",
        (entity_type, entity_id, change_type, summary, now())
    )


@app.get("/")
def home():
    return render_template("index.html")


@app.get("/health")
@app.get("/api/health/")
@app.get("/api/health")
def health():
    with connect_db() as conn:
        counts = {
            "products": conn.execute("SELECT COUNT(*) FROM products").fetchone()[0],
            "knowledge_entries": conn.execute("SELECT COUNT(*) FROM knowledge_entries").fetchone()[0],
            "algorithms": conn.execute("SELECT COUNT(*) FROM algorithms").fetchone()[0],
            "weaknesses": conn.execute("SELECT COUNT(*) FROM weaknesses").fetchone()[0]
        }
    return jsonify({"status": "ok", "database": "SQLite", "counts": counts})


@app.route("/api/products", methods=["GET", "POST"])
def products():
    if request.method == "GET":
        with connect_db() as conn:
            rows = conn.execute("SELECT * FROM products ORDER BY id DESC").fetchall()
        return jsonify([dict(r) for r in rows])
    data = request.get_json(silent=True) or {}
    name = str(data.get("name", "")).strip()
    if not name:
        return jsonify({"error": "Field 'name' is required"}), 400
    with connect_db() as conn:
        cur = conn.execute(
            "INSERT INTO products (name, category, description, created_at) VALUES (?, ?, ?, ?)",
            (name, data.get("category", ""), data.get("description", ""), now()))
        pid = cur.lastrowid
        log_change(conn, "product", pid, "created", f"Created product: {name}")
        row = conn.execute("SELECT * FROM products WHERE id=?", (pid,)).fetchone()
    return jsonify(dict(row)), 201


@app.route("/api/products/<int:pid>", methods=["GET", "PUT", "DELETE"])
def product_detail(pid):
    with connect_db() as conn:
        row = conn.execute("SELECT * FROM products WHERE id=?", (pid,)).fetchone()
        if not row:
            return jsonify({"error": "Product not found"}), 404
        if request.method == "GET":
            return jsonify(dict(row))
        if request.method == "PUT":
            data = request.get_json(silent=True) or {}
            name = data.get("name", row["name"])
            category = data.get("category", row["category"])
            description = data.get("description", row["description"])
            conn.execute("UPDATE products SET name=?, category=?, description=? WHERE id=?",
                         (name, category, description, pid))
            log_change(conn, "product", pid, "updated", f"Updated product: {name}")
            return jsonify(dict(conn.execute("SELECT * FROM products WHERE id=?", (pid,)).fetchone()))
        conn.execute("DELETE FROM products WHERE id=?", (pid,))
        log_change(conn, "product", pid, "deleted", f"Deleted product id {pid}")
    return jsonify({"message": "Product deleted", "id": pid})


@app.route("/api/knowledge", methods=["GET", "POST"])
def knowledge():
    if request.method == "GET":
        pid = request.args.get("product_id", type=int)
        with connect_db() as conn:
            if pid:
                rows = conn.execute(
                    "SELECT * FROM knowledge_entries WHERE product_id=? ORDER BY topic, version DESC",
                    (pid,)).fetchall()
            else:
                rows = conn.execute("SELECT * FROM knowledge_entries ORDER BY id DESC").fetchall()
        return jsonify([dict(r) for r in rows])
    data = request.get_json(silent=True) or {}
    pid = data.get("product_id")
    topic = str(data.get("topic", "")).strip()
    content = str(data.get("content", "")).strip()
    if not pid or not topic or not content:
        return jsonify({"error": "Fields 'product_id', 'topic', and 'content' are required"}), 400
    with connect_db() as conn:
        if not conn.execute("SELECT id FROM products WHERE id=?", (pid,)).fetchone():
            return jsonify({"error": "Product not found; create it first"}), 404
        cur = conn.execute(
            """INSERT INTO knowledge_entries
            (product_id, topic, content, version, valid_from, valid_to, source, confidence)
            VALUES (?, ?, ?, 1, ?, NULL, ?, ?)""",
            (pid, topic, content, now(), data.get("source", ""), float(data.get("confidence", 1.0))))
        eid = cur.lastrowid
        log_change(conn, "knowledge", eid, "created", f"Added knowledge topic '{topic}'")
        row = conn.execute("SELECT * FROM knowledge_entries WHERE id=?", (eid,)).fetchone()
    return jsonify(dict(row)), 201


@app.route("/api/knowledge/<int:eid>", methods=["PUT", "DELETE"])
def knowledge_detail(eid):
    with connect_db() as conn:
        old = conn.execute("SELECT * FROM knowledge_entries WHERE id=?", (eid,)).fetchone()
        if not old:
            return jsonify({"error": "Knowledge entry not found"}), 404
        if request.method == "DELETE":
            conn.execute("DELETE FROM knowledge_entries WHERE id=?", (eid,))
            log_change(conn, "knowledge", eid, "deleted", f"Deleted knowledge entry {eid}")
            return jsonify({"message": "Knowledge entry deleted"})
        data = request.get_json(silent=True) or {}
        topic = str(data.get("topic", old["topic"])).strip()
        content = str(data.get("content", old["content"])).strip()
        timestamp = now()
        conn.execute("UPDATE knowledge_entries SET valid_to=? WHERE id=?", (timestamp, eid))
        cur = conn.execute(
            """INSERT INTO knowledge_entries
            (product_id, topic, content, version, valid_from, valid_to, source, confidence)
            VALUES (?, ?, ?, ?, ?, NULL, ?, ?)""",
            (old["product_id"], topic, content, old["version"] + 1, timestamp,
             data.get("source", old["source"]), float(data.get("confidence", old["confidence"]))))
        new_id = cur.lastrowid
        log_change(conn, "knowledge", new_id, "versioned",
                   f"Knowledge topic '{topic}' advanced to version {old['version'] + 1}")
        row = conn.execute("SELECT * FROM knowledge_entries WHERE id=?", (new_id,)).fetchone()
    return jsonify(dict(row)), 201


@app.get("/api/knowledge/<int:eid>/history")
def knowledge_history(eid):
    with connect_db() as conn:
        entry = conn.execute("SELECT product_id, topic FROM knowledge_entries WHERE id=?", (eid,)).fetchone()
        if not entry:
            return jsonify({"error": "Knowledge entry not found"}), 404
        rows = conn.execute(
            "SELECT * FROM knowledge_entries WHERE product_id=? AND topic=? ORDER BY version",
            (entry["product_id"], entry["topic"])).fetchall()
    return jsonify([dict(r) for r in rows])


@app.route("/api/algorithms", methods=["GET", "POST"])
def algorithms():
    if request.method == "GET":
        with connect_db() as conn:
            rows = conn.execute("SELECT * FROM algorithms ORDER BY id DESC").fetchall()
        return jsonify([dict(r) for r in rows])
    data = request.get_json(silent=True) or {}
    name = str(data.get("name", "")).strip()
    if not name:
        return jsonify({"error": "Field 'name' is required"}), 400
    with connect_db() as conn:
        cur = conn.execute(
            "INSERT INTO algorithms (name, purpose, steps, status, created_at) VALUES (?, ?, ?, ?, ?)",
            (name, data.get("purpose", ""), data.get("steps", ""),
             data.get("status", "incomplete"), now()))
        aid = cur.lastrowid
        log_change(conn, "algorithm", aid, "created", f"Created algorithm: {name}")
        row = conn.execute("SELECT * FROM algorithms WHERE id=?", (aid,)).fetchone()
    return jsonify(dict(row)), 201


@app.route("/api/algorithms/<int:aid>", methods=["GET", "PUT"])
def algorithm_detail(aid):
    with connect_db() as conn:
        row = conn.execute("SELECT * FROM algorithms WHERE id=?", (aid,)).fetchone()
        if not row:
            return jsonify({"error": "Algorithm not found"}), 404
        if request.method == "GET":
            return jsonify(dict(row))
        data = request.get_json(silent=True) or {}
        name, purpose = data.get("name", row["name"]), data.get("purpose", row["purpose"])
        steps, status = data.get("steps", row["steps"]), data.get("status", row["status"])
        conn.execute("UPDATE algorithms SET name=?, purpose=?, steps=?, status=? WHERE id=?",
                     (name, purpose, steps, status, aid))
        log_change(conn, "algorithm", aid, "updated", f"Updated algorithm: {name}; status={status}")
        return jsonify(dict(conn.execute("SELECT * FROM algorithms WHERE id=?", (aid,)).fetchone()))


@app.route("/api/algorithms/<int:aid>/weaknesses", methods=["GET", "POST"])
def algorithm_weaknesses(aid):
    with connect_db() as conn:
        if not conn.execute("SELECT id FROM algorithms WHERE id=?", (aid,)).fetchone():
            return jsonify({"error": "Algorithm not found"}), 404
        if request.method == "GET":
            rows = conn.execute("SELECT * FROM weaknesses WHERE algorithm_id=? ORDER BY id DESC", (aid,)).fetchall()
            return jsonify([dict(r) for r in rows])
        data = request.get_json(silent=True) or {}
        desc = str(data.get("description", "")).strip()
        if not desc:
            return jsonify({"error": "Field 'description' is required"}), 400
        cur = conn.execute(
            """INSERT INTO weaknesses (algorithm_id, description, severity, mitigation, created_at)
            VALUES (?, ?, ?, ?, ?)""",
            (aid, desc, data.get("severity", "medium"), data.get("mitigation", ""), now()))
        wid = cur.lastrowid
        log_change(conn, "weakness", wid, "created", f"Added weakness to algorithm {aid}")
        row = conn.execute("SELECT * FROM weaknesses WHERE id=?", (wid,)).fetchone()
    return jsonify(dict(row)), 201


@app.get("/api/evolution")
def evolution():
    limit = max(1, min(request.args.get("limit", default=100, type=int), 500))
    with connect_db() as conn:
        rows = conn.execute("SELECT * FROM evolution_log ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    return jsonify([dict(r) for r in rows])


@app.errorhandler(404)
def not_found(_error):
    return jsonify({"error": "Route not found", "requested_path": request.path,
                    "try": ["/", "/api/health", "/api/products", "/api/knowledge",
                            "/api/algorithms", "/api/evolution"]}), 404


init_db()

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
