TEMPORAL PRODUCT KNOWLEDGE SYSTEM — QUICK START

1. Copy app.py and the templates folder into your existing project folder.
2. Keep your existing .venv folder. Existing SQLite data is preserved if the database filename is temporal_product_knowledge.db.
3. Open PowerShell in the project folder and run:
   .\.venv\Scripts\python.exe app.py
4. Open http://127.0.0.1:5000/ in the same computer's browser.
5. Add a product first, then add knowledge. The knowledge API preserves versions when updated through PUT /api/knowledge/<id>.

Dependencies (if needed):
   pip install flask flask-cors

This is a local development demo, not a public deployment.
